# 🏠 Smart-Stay — Upgraded Setup Guide

## What Was Fixed & Added

| Task | Feature | Status |
|------|---------|--------|
| 1 | Eye icon to show/hide password on Login page | ✅ Done |
| 1 | Fixed Forgot Password → email sent → reset link works | ✅ Done |
| 1 | Fixed Reset Password page reads token from URL | ✅ Done |
| 2 | Edit tenant profile (name, phone, room, photo) | ✅ Done |
| 2 | Delete tenant with confirmation dialog | ✅ Done |
| 2 | Undo Vacated — reactivate tenant back to Active | ✅ Done |
| 3 | Edit payment entries | ✅ Done |
| 3 | Delete payment entries | ✅ Done |
| 3 | Date Range Filter on Payments page | ✅ Done |
| 3 | Utility bills (electricity/water) neat card layout | ✅ Done |
| 4 | Date Range Filter on Reports page | ✅ Done |
| 5 | Auto SMS via Twilio when notice posted | ✅ Done |
| 6 | Full UI overhaul — dark sidebar, premium cards | ✅ Done |
| 7 | Dashboard analytics: defaulters list, occupancy bar | ✅ Done |
| 7 | Revenue trend bar chart (last 6 months) | ✅ Done |
| 7 | PDF receipt download per payment | ✅ Done |

---

## Folder Structure

```
smartstay-upgraded/
├── backend/
│   ├── .env                    ← YOUR KEYS GO HERE
│   ├── requirements.txt
│   └── app/
│       ├── main.py
│       ├── models.py
│       ├── schemas.py
│       ├── auth.py
│       ├── database.py
│       ├── routers/
│       │   ├── hostels.py      (auth: login, register, forgot/reset password)
│       │   ├── tenants.py      ← UPGRADED: edit, delete, undo-vacated
│       │   ├── payments.py     ← UPGRADED: edit, delete, date range filter
│       │   ├── reports.py      ← UPGRADED: date range filter + revenue trend
│       │   ├── notices.py      ← UPGRADED: Twilio SMS integration
│       │   ├── rooms.py
│       │   ├── dashboard.py
│       │   └── electricity.py
│       └── utils/
│           ├── email.py
│           └── file_upload.py
└── frontend/
    └── src/
        ├── App.jsx             ← UPGRADED: clean routes
        ├── index.css           ← UPGRADED: premium design system
        ├── components/
        │   └── Layout.jsx      ← UPGRADED: dark sidebar
        └── pages/
            ├── Login.jsx       ← UPGRADED: eye icon, premium design
            ├── Auth.jsx        ← UPGRADED: working forgot/reset password
            ├── Dashboard.jsx   ← UPGRADED: analytics, defaulters, trend
            ├── Tenants.jsx     ← UPGRADED: edit, delete, undo vacated
            ├── TenantProfile.jsx ← UPGRADED: undo vacated, PDF receipt
            ├── Payments.jsx    ← UPGRADED: edit, delete, date range, utility cards
            └── Reports.jsx     ← UPGRADED: date range, revenue chart
```

---

## Step 1 — Backend Setup

### 1.1 Install PostgreSQL
```bash
# Ubuntu/Debian
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo -u postgres psql -c "CREATE DATABASE smartstay;"
sudo -u postgres psql -c "CREATE USER postgres WITH PASSWORD 'yourpassword';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE smartstay TO postgres;"
```

### 1.2 Configure .env
Open `backend/.env` and fill in:

```env
DATABASE_URL=postgresql://postgres:yourpassword@localhost:5432/smartstay
SECRET_KEY=any-long-random-string-here

# For password reset emails (Gmail):
SMTP_EMAIL=yourgmail@gmail.com
SMTP_PASSWORD=your_16char_app_password   # from Google App Passwords

# For SMS notifications (Twilio):
TWILIO_SID=ACxxxxxxxxxx
TWILIO_TOKEN=xxxxxxxxxxxx
TWILIO_FROM=+1xxxxxxxxxx
```

### 1.3 Create virtual environment & install
```bash
cd backend
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 1.4 Start backend
```bash
uvicorn app.main:app --reload --port 8000
```
Backend runs at: http://localhost:8000
API docs at: http://localhost:8000/docs

---

## Step 2 — Frontend Setup

```bash
cd frontend
npm install
npm run dev
```
Frontend runs at: http://localhost:5173

---

## Step 3 — Gmail App Password (for Forgot Password email)

1. Go to https://myaccount.google.com/security
2. Enable **2-Step Verification**
3. Go to **App Passwords** → Select "Mail" → "Other (Custom)" → Generate
4. Copy the 16-character password into `.env` as `SMTP_PASSWORD`

---

## Step 4 — Twilio SMS Setup (for Notice Board)

1. Sign up at https://www.twilio.com (free trial = $15 credit ≈ 500 SMS)
2. Go to Console → get **Account SID** and **Auth Token**
3. Get a phone number (free trial gives you one)
4. Add to `.env`:
   ```
   TWILIO_SID=ACxxxxxxxx
   TWILIO_TOKEN=xxxxxxxx
   TWILIO_FROM=+1xxxxxxxxxx
   SMS_COUNTRY_CODE=+91
   ```
5. `pip install twilio` (already in requirements.txt)
6. Restart backend — SMS will now send on every notice posted

### Indian SMS Alternatives (cheaper):
- **MSG91**: ₹0.20/SMS — https://msg91.com
- **Fast2SMS**: ₹0.15/SMS — https://fast2sms.com
- To use: edit `send_sms_to_tenants()` in `backend/app/routers/notices.py`

---

## Step 5 — Cloudinary (photo/PDF uploads)

1. Sign up at https://cloudinary.com (free: 25GB)
2. Get `cloud_name`, `api_key`, `api_secret` from dashboard
3. Add to `.env`

---

## New Backend API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| PUT    | `/api/tenants/{id}/edit` | Edit tenant profile |
| DELETE | `/api/tenants/{id}` | Delete tenant |
| PATCH  | `/api/tenants/{id}/undo-vacated` | Reactivate vacated tenant |
| PUT    | `/api/payments/{id}` | Edit payment |
| DELETE | `/api/payments/{id}` | Delete payment |
| GET    | `/api/payments/?start_date=&end_date=` | Date range filter |
| GET    | `/api/reports/revenue-trend?months=6` | Revenue trend data |
| GET    | `/api/reports/defaulters?start_date=&end_date=` | Defaulters with range |

---

## Running Both Together

Open two terminals:

**Terminal 1 (Backend):**
```bash
cd smartstay-upgraded/backend
source venv/bin/activate
uvicorn app.main:app --reload --port 8000
```

**Terminal 2 (Frontend):**
```bash
cd smartstay-upgraded/frontend
npm run dev
```

Then open: **http://localhost:5173**

---

## Pro Tips

- **Default admin**: Register a new account at `/register` — there's no default login
- **First steps after login**: Add Rooms → Add Tenants → Set Rent Config → Record Payments
- **PDF Receipts**: On Tenant Profile page, click the download icon on any payment row
- **Printing Reports**: Go to Reports page → click "Print / PDF" button
- **SMS stub mode**: If Twilio is not configured, notices still work but SMS is only logged in backend console — safe for development
