"""
routers/notices.py - Notice board with Twilio SMS integration
SMS is sent automatically when a notice is posted.
Configuration in .env:
  TWILIO_SID=ACxxxxxxxxxxxx
  TWILIO_TOKEN=xxxxxxxxxxxxxxxx
  TWILIO_FROM=+1xxxxxxxxxx          # Twilio phone number
  SMS_COUNTRY_CODE=+91              # Default country code prefix (India)
"""

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List
import os

from app.database import get_db
from app import models, schemas
from app.auth import get_current_hostel

router = APIRouter()


def send_sms_to_tenants(tenants, notice_title: str, notice_content: str):
    """
    Send SMS to all active tenants via Twilio.

    Setup steps:
    1. pip install twilio
    2. Sign up at https://www.twilio.com and get a trial/paid number
    3. Add to backend/.env:
         TWILIO_SID=ACxxxxx
         TWILIO_TOKEN=xxxxx
         TWILIO_FROM=+1xxxxxxxxxx
         SMS_COUNTRY_CODE=+91
    4. Restart the backend server

    For Indian gateways (cheaper alternative):
    - MSG91: https://msg91.com  — set MSG91_KEY instead of Twilio vars
    - Fast2SMS: https://www.fast2sms.com
    """
    sid     = os.getenv("TWILIO_SID")
    token   = os.getenv("TWILIO_TOKEN")
    from_   = os.getenv("TWILIO_FROM")
    country = os.getenv("SMS_COUNTRY_CODE", "+91")

    message_body = f"📢 {notice_title}\n\n{notice_content}\n\n- Smart-Stay Management"

    if sid and token and from_:
        try:
            from twilio.rest import Client
            client = Client(sid, token)
            for tenant in tenants:
                phone = tenant.phone.strip()
                if not phone.startswith("+"):
                    phone = country + phone
                try:
                    client.messages.create(
                        body  = message_body,
                        from_ = from_,
                        to    = phone
                    )
                    print(f"✅ SMS sent to {tenant.name} ({phone})")
                except Exception as sms_err:
                    print(f"⚠️ SMS failed for {tenant.name} ({phone}): {sms_err}")
        except ImportError:
            print("❌ Twilio not installed. Run: pip install twilio")
        except Exception as e:
            print(f"❌ Twilio init failed: {e}")
    else:
        # Dev mode — log to console instead of sending real SMS
        print(f"\n{'='*50}")
        print(f"[SMS STUB — configure Twilio in .env to send real SMS]")
        print(f"Notice: {notice_title}")
        print(f"Recipients: {[t.name + ' (' + t.phone + ')' for t in tenants]}")
        print(f"{'='*50}\n")


@router.get("/", response_model=List[schemas.NoticeResponse])
def list_notices(
    db: Session = Depends(get_db),
    current_hostel: models.Hostel = Depends(get_current_hostel)
):
    return db.query(models.Notice).filter(
        models.Notice.hostel_id == current_hostel.hostel_id
    ).order_by(models.Notice.created_at.desc()).limit(20).all()


@router.post("/", response_model=schemas.NoticeResponse, status_code=201)
def create_notice(
    payload: schemas.NoticeCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_hostel: models.Hostel = Depends(get_current_hostel)
):
    notice = models.Notice(
        hostel_id = current_hostel.hostel_id,
        title     = payload.title,
        content   = payload.content
    )
    db.add(notice)
    db.commit()
    db.refresh(notice)

    # Fetch active tenants and send SMS in background (non-blocking)
    active_tenants = db.query(models.Tenant).filter(
        models.Tenant.hostel_id == current_hostel.hostel_id,
        models.Tenant.status    == "Active"
    ).all()

    # Run SMS in background so the API responds immediately
    background_tasks.add_task(
        send_sms_to_tenants,
        list(active_tenants),
        payload.title,
        payload.content
    )

    return notice


@router.delete("/{notice_id}")
def delete_notice(
    notice_id: int,
    db: Session = Depends(get_db),
    current_hostel: models.Hostel = Depends(get_current_hostel)
):
    notice = db.query(models.Notice).filter(
        models.Notice.notice_id == notice_id,
        models.Notice.hostel_id == current_hostel.hostel_id
    ).first()
    if not notice:
        raise HTTPException(status_code=404, detail="Notice not found")
    db.delete(notice)
    db.commit()
    return {"message": "Notice deleted"}
