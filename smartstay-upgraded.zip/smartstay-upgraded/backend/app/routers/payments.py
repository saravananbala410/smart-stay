"""
routers/payments.py - Payment management with:
NEW: Edit payment  PUT  /{payment_id}
NEW: Delete payment  DELETE  /{payment_id}
NEW: Date range filter  GET /?start_date=YYYY-MM&end_date=YYYY-MM
FIXED: Monthly generation, arrears logic
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime, date
from typing import Optional
from pydantic import BaseModel

from app.database import get_db
from app import models, schemas
from app.auth import get_current_hostel

router = APIRouter()


def get_total_due_for_tenant(tenant, month_year: str, db: Session, hid: int) -> dict:
    if tenant.room:
        rent_config = db.query(models.RentConfiguration).filter(
            models.RentConfiguration.hostel_id    == hid,
            models.RentConfiguration.sharing_type == tenant.room.sharing_type
        ).order_by(models.RentConfiguration.effective_date.desc()).first()
        base_rent = rent_config.rent_amount if rent_config else tenant.room.base_rent
    else:
        base_rent = 0

    elec_amount = 0
    if tenant.room:
        elec_bill = db.query(models.ElectricityBill).filter(
            models.ElectricityBill.hostel_id   == hid,
            models.ElectricityBill.room_number == tenant.room.room_number,
            models.ElectricityBill.month_year  == month_year
        ).first()
        if elec_bill:
            elec_amount = elec_bill.per_tenant

    add_amount = 0
    add_charges = db.query(models.AdditionalCharge).filter(
        models.AdditionalCharge.hostel_id  == hid,
        models.AdditionalCharge.month_year == month_year
    ).all()
    for ac in add_charges:
        add_amount += ac.per_tenant

    return {
        "base_rent": base_rent,
        "electricity_amount": elec_amount,
        "additional_amount": add_amount,
        "total": base_rent + elec_amount + add_amount
    }


# ──────────────────────────────────────────────
# POST / — Record new payment
# ──────────────────────────────────────────────
@router.post("/", status_code=201)
def record_payment(
    payload: schemas.PaymentCreate,
    db: Session = Depends(get_db),
    current_hostel: models.Hostel = Depends(get_current_hostel)
):
    hid = current_hostel.hostel_id

    tenant = db.query(models.Tenant).filter(
        models.Tenant.tenant_id == payload.tenant_id,
        models.Tenant.hostel_id == hid
    ).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")

    existing = db.query(models.Payment).filter(
        models.Payment.tenant_id  == payload.tenant_id,
        models.Payment.month_year == payload.month_year
    ).first()

    if existing:
        existing.amount_paid += payload.amount_paid
        existing.payment_date = datetime.utcnow()
        if payload.transaction_id:
            existing.transaction_id = payload.transaction_id
        db.commit()
        balance = max(0, (existing.due_amount + existing.electricity_amount + existing.additional_amount) - existing.amount_paid + existing.arrears)
        return {"message": "Payment updated", "paid": existing.amount_paid, "balance": round(balance, 2)}

    due_info  = get_total_due_for_tenant(tenant, payload.month_year, db, hid)
    due_amount  = due_info["base_rent"]
    elec_amount = due_info["electricity_amount"]
    add_amount  = due_info["additional_amount"]

    prev = db.query(models.Payment).filter(
        models.Payment.tenant_id == payload.tenant_id
    ).order_by(models.Payment.month_year.desc()).first()
    arrears = 0
    if prev:
        prev_total = prev.due_amount + prev.electricity_amount + prev.additional_amount
        arrears = max(0, prev_total - prev.amount_paid + prev.arrears)

    payment = models.Payment(
        tenant_id          = payload.tenant_id,
        hostel_id          = hid,
        amount_paid        = payload.amount_paid,
        due_amount         = due_amount,
        electricity_amount = elec_amount,
        additional_amount  = add_amount,
        arrears            = arrears,
        payment_date       = datetime.utcnow(),
        month_year         = payload.month_year,
        transaction_id     = payload.transaction_id,
        is_advance         = payload.is_advance
    )
    db.add(payment)
    db.commit()

    total_due = due_amount + elec_amount + add_amount
    balance   = max(0, total_due - payload.amount_paid + arrears)
    return {
        "message"   : "Payment recorded",
        "rent"      : due_amount,
        "electricity": elec_amount,
        "additional": add_amount,
        "total_due" : total_due,
        "arrears"   : arrears,
        "amount_paid": payload.amount_paid,
        "balance"   : round(balance, 2)
    }


# ──────────────────────────────────────────────
# GET / — List payments with optional date range filter  ← ENHANCED
# ──────────────────────────────────────────────
@router.get("/")
def list_payments(
    month_year : Optional[str] = None,
    start_date : Optional[str] = None,   # "YYYY-MM" inclusive
    end_date   : Optional[str] = None,   # "YYYY-MM" inclusive
    db: Session = Depends(get_db),
    current_hostel: models.Hostel = Depends(get_current_hostel)
):
    query = db.query(models.Payment).filter(
        models.Payment.hostel_id == current_hostel.hostel_id
    )
    if month_year:
        query = query.filter(models.Payment.month_year == month_year)
    if start_date:
        query = query.filter(models.Payment.month_year >= start_date)
    if end_date:
        query = query.filter(models.Payment.month_year <= end_date)

    payments = query.order_by(models.Payment.created_at.desc()).all()

    result = []
    for p in payments:
        tenant_name = p.tenant.name if p.tenant else f"Tenant #{p.tenant_id}"
        total_due   = p.due_amount + p.electricity_amount + p.additional_amount
        balance     = max(0, total_due - p.amount_paid + p.arrears)
        result.append({
            "payment_id"        : p.payment_id,
            "tenant_id"         : p.tenant_id,
            "tenant_name"       : tenant_name,
            "due_amount"        : p.due_amount,
            "electricity_amount": p.electricity_amount,
            "additional_amount" : p.additional_amount,
            "total_due"         : total_due,
            "arrears"           : p.arrears,
            "amount_paid"       : p.amount_paid,
            "balance"           : round(balance, 2),
            "payment_date"      : p.payment_date,
            "month_year"        : p.month_year,
            "transaction_id"    : p.transaction_id,
            "is_advance"        : p.is_advance
        })
    return result


# ──────────────────────────────────────────────
# PUT /{payment_id} — Edit payment  ← NEW
# ──────────────────────────────────────────────
class PaymentEdit(BaseModel):
    amount_paid    : Optional[float] = None
    transaction_id : Optional[str]  = None
    month_year     : Optional[str]  = None

@router.put("/{payment_id}")
def edit_payment(
    payment_id: int,
    payload: PaymentEdit,
    db: Session = Depends(get_db),
    current_hostel: models.Hostel = Depends(get_current_hostel)
):
    payment = db.query(models.Payment).filter(
        models.Payment.payment_id == payment_id,
        models.Payment.hostel_id  == current_hostel.hostel_id
    ).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")

    if payload.amount_paid is not None:
        payment.amount_paid = payload.amount_paid
    if payload.transaction_id is not None:
        payment.transaction_id = payload.transaction_id
    if payload.month_year is not None:
        payment.month_year = payload.month_year
    payment.payment_date = datetime.utcnow()

    db.commit()
    total_due = payment.due_amount + payment.electricity_amount + payment.additional_amount
    balance   = max(0, total_due - payment.amount_paid + payment.arrears)
    return {"message": "Payment updated", "balance": round(balance, 2)}


# ──────────────────────────────────────────────
# DELETE /{payment_id} — Delete payment  ← NEW
# ──────────────────────────────────────────────
@router.delete("/{payment_id}")
def delete_payment(
    payment_id: int,
    db: Session = Depends(get_db),
    current_hostel: models.Hostel = Depends(get_current_hostel)
):
    payment = db.query(models.Payment).filter(
        models.Payment.payment_id == payment_id,
        models.Payment.hostel_id  == current_hostel.hostel_id
    ).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")

    db.delete(payment)
    db.commit()
    return {"message": "Payment deleted successfully"}


# ──────────────────────────────────────────────
# POST /generate-monthly — Bulk generate monthly bills
# ──────────────────────────────────────────────
@router.post("/generate-monthly")
def generate_monthly_bills(
    month_year: str,
    db: Session = Depends(get_db),
    current_hostel: models.Hostel = Depends(get_current_hostel)
):
    hid = current_hostel.hostel_id

    active_tenants = db.query(models.Tenant).filter(
        models.Tenant.hostel_id == hid,
        models.Tenant.status    == "Active"
    ).all()

    generated = 0
    for tenant in active_tenants:
        existing = db.query(models.Payment).filter(
            models.Payment.tenant_id  == tenant.tenant_id,
            models.Payment.month_year == month_year
        ).first()
        if existing or not tenant.room:
            continue

        due_info    = get_total_due_for_tenant(tenant, month_year, db, hid)
        due_amount  = due_info["base_rent"]
        elec_amount = due_info["electricity_amount"]
        add_amount  = due_info["additional_amount"]

        prev = db.query(models.Payment).filter(
            models.Payment.tenant_id == tenant.tenant_id
        ).order_by(models.Payment.month_year.desc()).first()
        arrears = 0
        if prev:
            prev_total = prev.due_amount + prev.electricity_amount + prev.additional_amount
            arrears = max(0, prev_total - prev.amount_paid + prev.arrears)

        payment = models.Payment(
            tenant_id          = tenant.tenant_id,
            hostel_id          = hid,
            amount_paid        = 0,
            due_amount         = due_amount,
            electricity_amount = elec_amount,
            additional_amount  = add_amount,
            arrears            = arrears,
            month_year         = month_year,
        )
        db.add(payment)
        generated += 1

    db.commit()
    return {"message": f"Generated {generated} payment entries for {month_year}"}
