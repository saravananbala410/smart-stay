import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import Login from './pages/Login'
import { Register, ForgotPassword, ResetPassword } from './pages/Auth'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Rooms from './pages/Rooms'
import Tenants from './pages/Tenants'
import TenantProfile from './pages/TenantProfile'
import Payments from './pages/Payments'
import Reports from './pages/Reports'

const PrivateRoute = ({ children }) =>
  localStorage.getItem('token') ? children : <Navigate to="/login" replace />

export default function App() {
  return (
    <BrowserRouter>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            borderRadius: '10px',
            background: '#0f172a',
            color: '#f8fafc',
            fontSize: '13px',
            fontFamily: "'DM Sans', sans-serif"
          },
          success: { iconTheme: { primary: '#10b981', secondary: '#0f172a' } },
          error:   { iconTheme: { primary: '#ef4444', secondary: '#0f172a' } },
        }}
      />
      <Routes>
        <Route path="/login"           element={<Login />} />
        <Route path="/register"        element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password"  element={<ResetPassword />} />
        <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
          <Route index                  element={<Dashboard />} />
          <Route path="rooms"           element={<Rooms />} />
          <Route path="tenants"         element={<Tenants />} />
          <Route path="tenants/:id"     element={<TenantProfile />} />
          <Route path="payments"        element={<Payments />} />
          <Route path="reports"         element={<Reports />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
