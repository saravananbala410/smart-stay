import { Outlet, NavLink, useNavigate, useLocation } from 'react-router-dom'
import {
  LayoutDashboard, Building2, Users, CreditCard,
  BarChart3, LogOut, Menu, X, BellRing, ChevronRight
} from 'lucide-react'
import { useState } from 'react'

const nav = [
  { to: '/',         icon: LayoutDashboard, label: 'Dashboard',  exact: true },
  { to: '/rooms',    icon: Building2,       label: 'Rooms' },
  { to: '/tenants',  icon: Users,           label: 'Tenants' },
  { to: '/payments', icon: CreditCard,      label: 'Payments' },
  { to: '/reports',  icon: BarChart3,       label: 'Reports' },
]

export default function Layout() {
  const navigate    = useNavigate()
  const location    = useLocation()
  const hostelName  = localStorage.getItem('hostel_name') || 'My Hostel'
  const [open, setOpen] = useState(false)

  const logout = () => {
    localStorage.clear()
    navigate('/login')
  }

  const SidebarContent = () => (
    <div className="flex flex-col h-full" style={{ background: 'var(--sidebar-bg)' }}>
      {/* Brand */}
      <div className="px-5 py-5" style={{ borderBottom: '1px solid var(--sidebar-border)' }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg"
            style={{ background: 'var(--accent)', boxShadow: '0 4px 14px var(--accent-glow)' }}>
            🏠
          </div>
          <div>
            <p className="font-bold text-white text-sm leading-tight">Smart-Stay</p>
            <p className="text-xs truncate max-w-[140px]" style={{ color: 'rgba(255,255,255,0.4)' }}>
              {hostelName}
            </p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        <p className="text-xs font-semibold px-3 pb-2 pt-1"
          style={{ color: 'rgba(255,255,255,0.25)', letterSpacing: '0.08em' }}>
          MENU
        </p>
        {nav.map(({ to, icon: Icon, label, exact }) => (
          <NavLink
            key={to} to={to} end={exact}
            onClick={() => setOpen(false)}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer
               ${isActive
                  ? 'nav-active text-indigo-300'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
               }`
            }
          >
            <Icon size={16} strokeWidth={isActive => isActive ? 2.2 : 1.8} />
            {label}
          </NavLink>
        ))}
      </nav>

      {/* User footer */}
      <div className="p-3" style={{ borderTop: '1px solid var(--sidebar-border)' }}>
        <button
          onClick={logout}
          className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm transition-all"
          style={{ color: 'rgba(255,255,255,0.4)' }}
          onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; e.currentTarget.style.color = 'rgba(255,255,255,0.8)' }}
          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'rgba(255,255,255,0.4)' }}
        >
          <LogOut size={15} />
          <span>Log out</span>
        </button>
      </div>
    </div>
  )

  // Get current page label for mobile header
  const currentPage = nav.find(n =>
    n.exact ? location.pathname === n.to : location.pathname.startsWith(n.to)
  )

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Desktop sidebar */}
      <div className="hidden md:flex flex-shrink-0 w-56">
        <SidebarContent />
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-40 flex md:hidden" onClick={() => setOpen(false)}>
          <div className="absolute inset-0" style={{ background: 'rgba(15,23,42,0.6)', backdropFilter: 'blur(4px)' }} />
          <div className="relative z-50 w-56 h-full" onClick={e => e.stopPropagation()}>
            <SidebarContent />
          </div>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile topbar */}
        <div className="md:hidden flex items-center gap-3 px-4 py-3 bg-white border-b border-slate-100 shadow-sm">
          <button
            onClick={() => setOpen(true)}
            className="p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <Menu size={20} style={{ color: 'var(--accent)' }} />
          </button>
          <div className="flex items-center gap-1.5 text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
            {currentPage && <currentPage.icon size={15} style={{ color: 'var(--accent)' }} />}
            {currentPage?.label || 'Smart-Stay'}
          </div>
        </div>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 page-enter">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
