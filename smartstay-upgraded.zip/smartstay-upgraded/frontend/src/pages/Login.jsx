import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Eye, EyeOff, Mail, Lock, ArrowRight } from 'lucide-react'
import api from '../api/axios'
import toast from 'react-hot-toast'

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' })
  const [loading, setLoading]   = useState(false)
  const [showPass, setShowPass] = useState(false)   // ← password visibility toggle
  const navigate = useNavigate()

  const submit = async e => {
    e.preventDefault()
    setLoading(true)
    try {
      const { data } = await api.post('/auth/login', form)
      localStorage.setItem('token',       data.access_token)
      localStorage.setItem('hostel_id',   data.hostel_id)
      localStorage.setItem('hostel_name', data.hostel_name)
      toast.success('Welcome back!')
      navigate('/')
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Login failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--sidebar-bg)' }}>
      {/* Left: Branding panel */}
      <div className="hidden lg:flex flex-col justify-between w-[420px] p-10 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #4c1d95 100%)' }}>
        {/* Decorative circles */}
        <div className="absolute -top-20 -left-20 w-80 h-80 rounded-full"
          style={{ background: 'rgba(99,102,241,0.15)' }} />
        <div className="absolute -bottom-10 -right-10 w-60 h-60 rounded-full"
          style={{ background: 'rgba(139,92,246,0.12)' }} />

        <div className="relative">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl mb-8"
            style={{ background: 'rgba(255,255,255,0.1)' }}>
            🏠
          </div>
          <h1 className="text-3xl font-bold text-white leading-tight mb-3">
            Smart-Stay
          </h1>
          <p className="text-base" style={{ color: 'rgba(255,255,255,0.5)' }}>
            Professional PG & Hostel<br />Management Platform
          </p>
        </div>

        <div className="relative space-y-4">
          {[
            { icon: '📊', text: 'Real-time revenue analytics' },
            { icon: '👥', text: 'Complete tenant management' },
            { icon: '📱', text: 'Automated SMS notifications' },
            { icon: '📄', text: 'Downloadable PDF receipts' },
          ].map(f => (
            <div key={f.text} className="flex items-center gap-3">
              <span className="text-lg">{f.icon}</span>
              <span className="text-sm" style={{ color: 'rgba(255,255,255,0.65)' }}>{f.text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Right: Login form */}
      <div className="flex-1 flex items-center justify-center p-6 bg-slate-50">
        <div className="w-full max-w-sm">
          {/* Mobile logo */}
          <div className="lg:hidden text-center mb-8">
            <div className="text-4xl mb-2">🏠</div>
            <h1 className="text-2xl font-bold text-slate-800">Smart-Stay</h1>
          </div>

          <div className="card p-8">
            <div className="mb-7">
              <h2 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>Sign in</h2>
              <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>
                Access your management dashboard
              </p>
            </div>

            <form onSubmit={submit} className="space-y-4">
              {/* Email */}
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Email address
                </label>
                <div className="relative">
                  <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2"
                    style={{ color: 'var(--text-muted)' }} />
                  <input
                    type="email"
                    required
                    className="input pl-9"
                    placeholder="admin@myhostel.com"
                    value={form.email}
                    onChange={e => setForm({ ...form, email: e.target.value })}
                  />
                </div>
              </div>

              {/* Password with eye toggle */}
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Password
                </label>
                <div className="relative">
                  <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2"
                    style={{ color: 'var(--text-muted)' }} />
                  <input
                    type={showPass ? 'text' : 'password'}
                    required
                    className="input pl-9 pr-10"
                    placeholder="••••••••"
                    value={form.password}
                    onChange={e => setForm({ ...form, password: e.target.value })}
                  />
                  {/* Eye icon toggle ← TASK 1 FIX */}
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-0.5 rounded transition-colors"
                    style={{ color: showPass ? 'var(--accent)' : 'var(--text-muted)' }}
                    title={showPass ? 'Hide password' : 'Show password'}
                  >
                    {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              {/* Forgot password link */}
              <div className="text-right">
                <Link
                  to="/forgot-password"
                  className="text-sm font-medium transition-colors"
                  style={{ color: 'var(--accent)' }}
                >
                  Forgot password?
                </Link>
              </div>

              <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-3">
                {loading ? (
                  <span className="flex items-center gap-2">
                    <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.4 0 0 5.4 0 12h4z"/>
                    </svg>
                    Signing in...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    Sign in <ArrowRight size={15} />
                  </span>
                )}
              </button>
            </form>
          </div>

          <p className="text-center text-sm mt-5" style={{ color: 'var(--text-muted)' }}>
            New to Smart-Stay?{' '}
            <Link to="/register" className="font-semibold" style={{ color: 'var(--accent)' }}>
              Register your hostel
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
