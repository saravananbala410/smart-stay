import { useEffect, useState } from 'react'
import {
  Plus, Search, UserCircle, X, Users, UserX,
  Pencil, Trash2, RotateCcw, ChevronRight
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import api from '../api/axios'
import toast from 'react-hot-toast'

const BASE_URL = 'http://localhost:8000'

function getImageUrl(path) {
  if (!path) return null
  if (path.startsWith('http')) return path
  return `${BASE_URL}/uploads/${path.replace(/^uploads\//, '')}`
}

const Avatar = ({ tenant, size = 'md' }) => {
  const [imgErr, setImgErr] = useState(false)
  const cls = size === 'lg'
    ? 'w-12 h-12 rounded-xl text-base'
    : 'w-9 h-9 rounded-lg text-sm'
  const url = getImageUrl(tenant.photo_url)

  if (url && !imgErr) {
    return (
      <img
        src={url}
        alt={tenant.name}
        className={`${cls} object-cover border border-slate-100 flex-shrink-0`}
        onError={() => setImgErr(true)}
      />
    )
  }
  return (
    <div className={`${cls} flex items-center justify-center font-bold flex-shrink-0`}
      style={{ background: '#ede9fe', color: 'var(--accent)' }}>
      {tenant.name.charAt(0).toUpperCase()}
    </div>
  )
}

export default function Tenants() {
  const [tenants,  setTenants]  = useState([])
  const [rooms,    setRooms]    = useState([])
  const [search,   setSearch]   = useState('')
  const [tab,      setTab]      = useState('Active')
  const [showAdd,  setShowAdd]  = useState(false)
  const [editTenant, setEditTenant] = useState(null)    // tenant object to edit
  const [deleteTarget, setDeleteTarget] = useState(null)// tenant to delete
  const [loading,  setLoading]  = useState(false)
  const navigate = useNavigate()

  const [form, setForm] = useState({
    room_id: '', name: '', phone: '', aadhaar_number: '',
    emergency_contact: '', joining_date: new Date().toISOString().split('T')[0]
  })
  const [editForm, setEditForm] = useState({ name: '', phone: '', emergency_contact: '', room_id: '' })
  const [photo,     setPhoto]     = useState(null)
  const [aadhaarPdf, setAadhaarPdf] = useState(null)
  const [editPhoto,  setEditPhoto]  = useState(null)

  const load = (q = '', status = tab) => {
    let url = `/tenants/?status=${status}`
    if (q) url += `&search=${q}`
    api.get(url).then(r => setTenants(r.data)).catch(() => {})
  }

  const loadRooms = () => {
    api.get('/rooms/').then(r => setRooms(r.data)).catch(() => {})
  }

  useEffect(() => { load('', tab); loadRooms() }, [tab])

  useEffect(() => {
    const t = setTimeout(() => load(search, tab), 350)
    return () => clearTimeout(t)
  }, [search])

  // ── Add tenant ──────────────────────────────
  const addTenant = async e => {
    e.preventDefault()
    setLoading(true)
    try {
      const fd = new FormData()
      Object.entries(form).forEach(([k, v]) => fd.append(k, v))
      if (photo)      fd.append('photo', photo)
      if (aadhaarPdf) fd.append('aadhaar_pdf', aadhaarPdf)
      await api.post('/tenants/', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
      toast.success('Tenant added!')
      setShowAdd(false)
      setForm({ room_id: '', name: '', phone: '', aadhaar_number: '', emergency_contact: '', joining_date: new Date().toISOString().split('T')[0] })
      setPhoto(null); setAadhaarPdf(null)
      load()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to add tenant')
    } finally {
      setLoading(false)
    }
  }

  // ── Edit tenant ─────────────────────────────  TASK 2 FIX
  const openEdit = (t, e) => {
    e.stopPropagation()
    setEditTenant(t)
    setEditForm({
      name: t.name, phone: t.phone,
      emergency_contact: t.emergency_contact || '',
      room_id: t.room?.room_number ? String(
        rooms.find(r => r.room_number === t.room.room_number)?.room_id || ''
      ) : ''
    })
    setEditPhoto(null)
  }

  const saveEdit = async e => {
    e.preventDefault()
    setLoading(true)
    try {
      const fd = new FormData()
      fd.append('name',              editForm.name)
      fd.append('phone',             editForm.phone)
      fd.append('emergency_contact', editForm.emergency_contact || '')
      if (editForm.room_id) fd.append('room_id', editForm.room_id)
      if (editPhoto) fd.append('photo', editPhoto)
      await api.put(`/tenants/${editTenant.tenant_id}/edit`, fd, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      toast.success('Profile updated!')
      setEditTenant(null)
      load()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to update tenant')
    } finally {
      setLoading(false)
    }
  }

  // ── Delete tenant ───────────────────────────  TASK 2 FIX
  const confirmDelete = async () => {
    try {
      await api.delete(`/tenants/${deleteTarget.tenant_id}`)
      toast.success('Tenant deleted')
      setDeleteTarget(null)
      load()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to delete')
    }
  }

  // ── Undo vacated ────────────────────────────  TASK 2 FIX
  const undoVacated = async (t, e) => {
    e.stopPropagation()
    if (!window.confirm(`Reactivate ${t.name} as Active?`)) return
    try {
      await api.patch(`/tenants/${t.tenant_id}/undo-vacated`)
      toast.success(`${t.name} reactivated!`)
      load()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to reactivate')
    }
  }

  const vacantRooms = rooms.filter(r => r.vacant_beds > 0)

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Tenants</h1>
          <p className="page-sub">{tenants.length} {tab.toLowerCase()} {tenants.length === 1 ? 'tenant' : 'tenants'}</p>
        </div>
        <button onClick={() => setShowAdd(true)} className="btn-primary">
          <Plus size={14} /> Add Tenant
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 rounded-xl w-fit" style={{ background: '#f1f5f9' }}>
        {['Active', 'Vacated'].map(t => (
          <button key={t} onClick={() => { setTab(t); setSearch('') }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all"
            style={tab === t
              ? { background: 'white', color: 'var(--accent)', boxShadow: '0 1px 3px rgba(0,0,0,0.08)' }
              : { color: 'var(--text-secondary)' }
            }>
            {t === 'Active'
              ? <><Users size={13} /> Active</>
              : <><UserX size={13} /> Vacated</>
            }
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative">
        <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2"
          style={{ color: 'var(--text-muted)' }} />
        <input
          placeholder="Search by name or phone..."
          className="input pl-9"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {/* Tenant list */}
      <div className="card overflow-hidden">
        {tenants.length === 0 ? (
          <div className="text-center py-14" style={{ color: 'var(--text-muted)' }}>
            <UserCircle size={36} className="mx-auto mb-3 opacity-30" />
            <p className="text-sm">No {tab.toLowerCase()} tenants found</p>
          </div>
        ) : (
          <div style={{ divideColor: '#f8fafc' }}>
            {tenants.map((t, i) => (
              <div key={t.tenant_id}
                onClick={() => navigate(`/tenants/${t.tenant_id}`)}
                className="flex items-center gap-3.5 px-5 py-3.5 cursor-pointer transition-colors"
                style={{ borderBottom: i < tenants.length - 1 ? '1px solid #f8fafc' : 'none' }}
                onMouseEnter={e => e.currentTarget.style.background = '#fafbff'}
                onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
              >
                <Avatar tenant={t} />

                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>{t.name}</p>
                  <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
                    {t.phone}
                    {t.room ? ` · Room ${t.room.room_number}` : ''}
                    {t.vacated_date ? ` · Vacated ${new Date(t.vacated_date).toLocaleDateString('en-IN')}` : ''}
                  </p>
                </div>

                <span className={`badge ${t.status === 'Active' ? 'badge-green' : 'badge-gray'}`}>
                  {t.status}
                </span>

                {/* Action buttons */}
                <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                  {/* Edit */}
                  <button
                    onClick={e => openEdit(t, e)}
                    className="p-1.5 rounded-lg transition-colors"
                    style={{ color: 'var(--text-muted)' }}
                    onMouseEnter={e => { e.currentTarget.style.background = '#ede9fe'; e.currentTarget.style.color = 'var(--accent)' }}
                    onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--text-muted)' }}
                    title="Edit tenant"
                  >
                    <Pencil size={14} />
                  </button>

                  {/* Undo vacated (only for Vacated tab) */}
                  {t.status === 'Vacated' && (
                    <button
                      onClick={e => undoVacated(t, e)}
                      className="p-1.5 rounded-lg transition-colors"
                      style={{ color: 'var(--text-muted)' }}
                      onMouseEnter={e => { e.currentTarget.style.background = '#dcfce7'; e.currentTarget.style.color = '#15803d' }}
                      onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--text-muted)' }}
                      title="Undo vacated — reactivate"
                    >
                      <RotateCcw size={14} />
                    </button>
                  )}

                  {/* Delete */}
                  <button
                    onClick={e => { e.stopPropagation(); setDeleteTarget(t) }}
                    className="p-1.5 rounded-lg transition-colors"
                    style={{ color: 'var(--text-muted)' }}
                    onMouseEnter={e => { e.currentTarget.style.background = '#fee2e2'; e.currentTarget.style.color = 'var(--danger)' }}
                    onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--text-muted)' }}
                    title="Delete tenant"
                  >
                    <Trash2 size={14} />
                  </button>

                  <ChevronRight size={14} style={{ color: 'var(--text-muted)' }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ── Add Tenant Modal ── */}
      {showAdd && (
        <div className="modal-overlay" onClick={() => setShowAdd(false)}>
          <div className="modal p-7" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>Add New Tenant</h2>
              <button onClick={() => setShowAdd(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100" style={{ color: 'var(--text-muted)' }}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={addTenant} className="space-y-4 overflow-y-auto max-h-[70vh] pr-1">
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Room <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <select required value={form.room_id}
                  onChange={e => setForm({ ...form, room_id: e.target.value })} className="input">
                  <option value="">Select a room...</option>
                  {vacantRooms.map(r => (
                    <option key={r.room_id} value={r.room_id}>
                      Room {r.room_number} ({r.sharing_type}-sharing) — {r.vacant_beds} bed{r.vacant_beds !== 1 ? 's' : ''} vacant
                    </option>
                  ))}
                </select>
              </div>
              {[
                { label: 'Full Name',         key: 'name',              ph: 'Karthik R' },
                { label: 'Phone Number',      key: 'phone',             ph: '9876543210' },
                { label: 'Aadhaar Number',    key: 'aadhaar_number',    ph: '1234 5678 9012' },
                { label: 'Emergency Contact', key: 'emergency_contact', ph: '9876500000', req: false },
              ].map(({ label, key, ph, req = true }) => (
                <div key={key}>
                  <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                    {label} {req && <span style={{ color: 'var(--danger)' }}>*</span>}
                  </label>
                  <input type="text" required={req} placeholder={ph}
                    value={form[key]} onChange={e => setForm({ ...form, [key]: e.target.value })}
                    className="input" />
                </div>
              ))}
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Joining Date <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <input type="date" required value={form.joining_date}
                  onChange={e => setForm({ ...form, joining_date: e.target.value })} className="input" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Photo (optional)
                </label>
                <input type="file" accept="image/*" onChange={e => setPhoto(e.target.files[0])}
                  className="input text-sm py-2" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Aadhaar PDF (optional)
                </label>
                <input type="file" accept=".pdf" onChange={e => setAadhaarPdf(e.target.files[0])}
                  className="input text-sm py-2" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowAdd(false)} className="btn-secondary flex-1 justify-center">
                  Cancel
                </button>
                <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
                  {loading ? 'Adding...' : 'Add Tenant'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── Edit Tenant Modal ── TASK 2 FIX */}
      {editTenant && (
        <div className="modal-overlay" onClick={() => setEditTenant(null)}>
          <div className="modal p-7" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
                Edit Tenant — {editTenant.name}
              </h2>
              <button onClick={() => setEditTenant(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100" style={{ color: 'var(--text-muted)' }}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={saveEdit} className="space-y-4">
              {[
                { label: 'Full Name',         key: 'name',              ph: 'Tenant name' },
                { label: 'Phone Number',      key: 'phone',             ph: '9876543210' },
                { label: 'Emergency Contact', key: 'emergency_contact', ph: '9876500000', req: false },
              ].map(({ label, key, ph, req = true }) => (
                <div key={key}>
                  <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                    {label}
                  </label>
                  <input type="text" required={req} placeholder={ph}
                    value={editForm[key]} onChange={e => setEditForm({ ...editForm, [key]: e.target.value })}
                    className="input" />
                </div>
              ))}
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Change Room (optional)
                </label>
                <select value={editForm.room_id}
                  onChange={e => setEditForm({ ...editForm, room_id: e.target.value })} className="input">
                  <option value="">Keep current room</option>
                  {rooms.filter(r => r.vacant_beds > 0).map(r => (
                    <option key={r.room_id} value={r.room_id}>
                      Room {r.room_number} ({r.sharing_type}-sharing) — {r.vacant_beds} vacant
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Update Photo (optional)
                </label>
                <input type="file" accept="image/*" onChange={e => setEditPhoto(e.target.files[0])}
                  className="input text-sm py-2" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setEditTenant(null)} className="btn-secondary flex-1 justify-center">
                  Cancel
                </button>
                <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
                  {loading ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── Delete Confirmation Modal ── TASK 2 FIX */}
      {deleteTarget && (
        <div className="modal-overlay" onClick={() => setDeleteTarget(null)}>
          <div className="modal p-7 max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="text-center">
              <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
                style={{ background: '#fee2e2' }}>
                <Trash2 size={22} style={{ color: 'var(--danger)' }} />
              </div>
              <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
                Delete Tenant?
              </h3>
              <p className="text-sm mb-6" style={{ color: 'var(--text-muted)' }}>
                This will permanently delete <strong>{deleteTarget.name}</strong> and all their payment records.
                This cannot be undone.
              </p>
              <div className="flex gap-3">
                <button onClick={() => setDeleteTarget(null)} className="btn-secondary flex-1 justify-center">
                  Cancel
                </button>
                <button onClick={confirmDelete} className="btn-danger flex-1 justify-center">
                  Yes, Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
