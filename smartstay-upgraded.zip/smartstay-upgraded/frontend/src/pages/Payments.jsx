import { useEffect, useState } from 'react'
import {
  Plus, X, Search, Filter, CreditCard,
  Pencil, Trash2, Zap, Droplets, Calendar,
  IndianRupee, Download, CheckCircle, Clock
} from 'lucide-react'
import api from '../api/axios'
import toast from 'react-hot-toast'

export default function Payments() {
  const [payments,    setPayments]    = useState([])
  const [tenants,     setTenants]     = useState([])
  const [elecBills,   setElecBills]   = useState([])
  const [addCharges,  setAddCharges]  = useState([])
  const [rooms,       setRooms]       = useState([])
  const [loading,     setLoading]     = useState(false)

  // Filters
  const curMonth = new Date().toISOString().slice(0, 7)
  const [startDate, setStartDate] = useState(curMonth)
  const [endDate,   setEndDate]   = useState(curMonth)
  const [rangeMode, setRangeMode] = useState(false)    // false = single month, true = date range
  const [month,     setMonth]     = useState(curMonth)

  // Modal state
  const [showPayModal,  setShowPayModal]  = useState(false)
  const [editPayment,   setEditPayment]   = useState(null)
  const [deletePayment, setDeletePayment] = useState(null)
  const [showElecModal, setShowElecModal] = useState(false)
  const [showAddModal,  setShowAddModal]  = useState(false)

  // Forms
  const [payForm, setPayForm] = useState({
    tenant_id: '', amount_paid: '', month_year: curMonth, transaction_id: '', is_advance: false
  })
  const [elecForm, setElecForm] = useState({ room_number: '', total_amount: '', month_year: curMonth })
  const [addForm,  setAddForm]  = useState({ charge_name: '', total_amount: '', month_year: curMonth })
  const [editForm, setEditForm] = useState({ amount_paid: '', transaction_id: '', month_year: '' })

  const loadPayments = () => {
    let url = '/payments/?'
    if (rangeMode) {
      url += `start_date=${startDate}&end_date=${endDate}`
    } else {
      url += `month_year=${month}`
    }
    api.get(url).then(r => setPayments(r.data)).catch(() => {})
  }

  const loadBills = (m) => {
    const q = m || month
    api.get(`/charges/electricity?month_year=${q}`).then(r => setElecBills(r.data)).catch(() => {})
    api.get(`/charges/additional?month_year=${q}`).then(r => setAddCharges(r.data)).catch(() => {})
  }

  useEffect(() => {
    api.get('/tenants/?status=Active').then(r => setTenants(r.data)).catch(() => {})
    api.get('/rooms/').then(r => setRooms(r.data)).catch(() => {})
  }, [])

  useEffect(() => {
    loadPayments()
    loadBills()
  }, [month, startDate, endDate, rangeMode])

  // ── Record payment ─────────────────────────
  const submitPay = async e => {
    e.preventDefault()
    setLoading(true)
    try {
      await api.post('/payments/', {
        ...payForm,
        tenant_id:  Number(payForm.tenant_id),
        amount_paid: Number(payForm.amount_paid)
      })
      toast.success('Payment recorded!')
      setShowPayModal(false)
      setPayForm({ tenant_id: '', amount_paid: '', month_year: month, transaction_id: '', is_advance: false })
      loadPayments()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to record payment')
    } finally { setLoading(false) }
  }

  // ── Edit payment ───────────────────────────  TASK 3 FIX
  const openEdit = p => {
    setEditPayment(p)
    setEditForm({ amount_paid: String(p.amount_paid), transaction_id: p.transaction_id || '', month_year: p.month_year })
  }

  const saveEdit = async e => {
    e.preventDefault()
    setLoading(true)
    try {
      await api.put(`/payments/${editPayment.payment_id}`, {
        amount_paid: Number(editForm.amount_paid),
        transaction_id: editForm.transaction_id,
        month_year: editForm.month_year
      })
      toast.success('Payment updated!')
      setEditPayment(null)
      loadPayments()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to update')
    } finally { setLoading(false) }
  }

  // ── Delete payment ─────────────────────────  TASK 3 FIX
  const confirmDelete = async () => {
    try {
      await api.delete(`/payments/${deletePayment.payment_id}`)
      toast.success('Payment deleted')
      setDeletePayment(null)
      loadPayments()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to delete')
    }
  }

  // ── Electricity bill ───────────────────────
  const submitElec = async e => {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await api.post('/charges/electricity', {
        ...elecForm,
        total_amount: Number(elecForm.total_amount)
      })
      toast.success(`Electricity set! ₹${res.data.per_tenant}/tenant`)
      setShowElecModal(false)
      setElecForm({ room_number: '', total_amount: '', month_year: month })
      loadBills()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to set bill')
    } finally { setLoading(false) }
  }

  // ── Additional charge ──────────────────────
  const submitAdd = async e => {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await api.post('/charges/additional', {
        ...addForm,
        total_amount: Number(addForm.total_amount)
      })
      toast.success(`${addForm.charge_name} added! ₹${res.data.per_tenant}/tenant`)
      setShowAddModal(false)
      setAddForm({ charge_name: '', total_amount: '', month_year: month })
      loadBills()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to add charge')
    } finally { setLoading(false) }
  }

  const totalCollected = payments.reduce((s, p) => s + p.amount_paid, 0)
  const totalPending   = payments.reduce((s, p) => s + p.balance, 0)
  const totalElec      = elecBills.reduce((s, b) => s + b.total_amount, 0)
  const totalAdd       = addCharges.reduce((s, c) => s + c.total_amount, 0)

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Payments</h1>
          <p className="page-sub">{payments.length} records</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setShowElecModal(true)} className="btn-secondary">
            <Zap size={13} /> Electricity Bill
          </button>
          <button onClick={() => setShowAddModal(true)} className="btn-secondary">
            <Droplets size={13} /> Add Charge
          </button>
          <button onClick={() => setShowPayModal(true)} className="btn-primary">
            <Plus size={14} /> Record Payment
          </button>
        </div>
      </div>

      {/* Date Range Filter  TASK 3 FIX */}
      <div className="card p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 p-1 rounded-lg" style={{ background: '#f1f5f9' }}>
            {[{ v: false, l: 'Single Month' }, { v: true, l: 'Date Range' }].map(({ v, l }) => (
              <button key={String(v)} onClick={() => setRangeMode(v)}
                className="px-3 py-1.5 rounded-md text-sm font-medium transition-all"
                style={rangeMode === v
                  ? { background: 'white', color: 'var(--accent)', boxShadow: '0 1px 3px rgba(0,0,0,0.08)' }
                  : { color: 'var(--text-secondary)' }
                }>
                {l}
              </button>
            ))}
          </div>

          {rangeMode ? (
            <div className="flex items-center gap-2">
              <div>
                <label className="block text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>From</label>
                <input type="month" value={startDate} onChange={e => setStartDate(e.target.value)}
                  className="input py-2 text-sm" style={{ width: '150px' }} />
              </div>
              <span className="text-sm mt-4" style={{ color: 'var(--text-muted)' }}>→</span>
              <div>
                <label className="block text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>To</label>
                <input type="month" value={endDate} onChange={e => setEndDate(e.target.value)}
                  className="input py-2 text-sm" style={{ width: '150px' }} />
              </div>
            </div>
          ) : (
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Month</label>
              <input type="month" value={month} onChange={e => setMonth(e.target.value)}
                className="input py-2 text-sm" style={{ width: '160px' }} />
            </div>
          )}

          <div className="text-sm ml-auto" style={{ color: 'var(--text-muted)' }}>
            {payments.length} payments found
          </div>
        </div>
      </div>

      {/* Summary row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Collected',   value: `₹${totalCollected.toLocaleString('en-IN')}`, color: '#10b981', bg: '#f0fdf4' },
          { label: 'Pending',     value: `₹${totalPending.toLocaleString('en-IN')}`,   color: '#ef4444', bg: '#fef2f2' },
          { label: 'Electricity', value: `₹${totalElec.toLocaleString('en-IN')}`,      color: '#f59e0b', bg: '#fffbeb' },
          { label: 'Other Bills', value: `₹${totalAdd.toLocaleString('en-IN')}`,       color: '#3b82f6', bg: '#eff6ff' },
        ].map(c => (
          <div key={c.label} className="stat-card">
            <p className="text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>{c.label}</p>
            <p className="text-xl font-bold num" style={{ color: c.color }}>{c.value}</p>
          </div>
        ))}
      </div>

      {/* Utility Bills Display  TASK 3 FIX: neat explicit layout */}
      {(elecBills.length > 0 || addCharges.length > 0) && (
        <div className="grid md:grid-cols-2 gap-4">
          {/* Electricity Bills */}
          {elecBills.length > 0 && (
            <div className="card p-5">
              <h3 className="font-semibold text-sm flex items-center gap-2 mb-4"
                style={{ color: 'var(--text-primary)' }}>
                <Zap size={15} style={{ color: '#f59e0b' }} />
                Electricity Bills
                <span className="badge badge-yellow ml-auto">{elecBills.length} rooms</span>
              </h3>
              <div className="space-y-2">
                {elecBills.map(b => (
                  <div key={b.bill_id} className="flex items-center justify-between p-3 rounded-xl"
                    style={{ background: '#fffbeb', border: '1px solid #fef3c7' }}>
                    <div>
                      <p className="text-sm font-semibold" style={{ color: '#92400e' }}>Room {b.room_number}</p>
                      <p className="text-xs mt-0.5" style={{ color: '#a16207' }}>
                        Total bill: <span className="font-bold">₹{b.total_amount}</span>
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs" style={{ color: '#a16207' }}>Per tenant</p>
                      <p className="text-lg font-bold num" style={{ color: '#d97706' }}>₹{b.per_tenant}</p>
                    </div>
                  </div>
                ))}
                <div className="flex justify-between pt-2 border-t" style={{ borderColor: '#fef3c7' }}>
                  <span className="text-sm font-semibold" style={{ color: '#92400e' }}>Total Electricity</span>
                  <span className="text-sm font-bold num" style={{ color: '#d97706' }}>
                    ₹{totalElec.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Additional Charges */}
          {addCharges.length > 0 && (
            <div className="card p-5">
              <h3 className="font-semibold text-sm flex items-center gap-2 mb-4"
                style={{ color: 'var(--text-primary)' }}>
                <Droplets size={15} style={{ color: '#3b82f6' }} />
                Additional Charges
                <span className="badge badge-blue ml-auto">{addCharges.length} items</span>
              </h3>
              <div className="space-y-2">
                {addCharges.map(c => (
                  <div key={c.charge_id} className="flex items-center justify-between p-3 rounded-xl"
                    style={{ background: '#eff6ff', border: '1px solid #dbeafe' }}>
                    <div>
                      <p className="text-sm font-semibold" style={{ color: '#1e3a8a' }}>{c.charge_name}</p>
                      <p className="text-xs mt-0.5" style={{ color: '#1d4ed8' }}>
                        Total: <span className="font-bold">₹{c.total_amount}</span>
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs" style={{ color: '#1d4ed8' }}>Per tenant</p>
                      <p className="text-lg font-bold num" style={{ color: '#2563eb' }}>₹{c.per_tenant}</p>
                    </div>
                  </div>
                ))}
                <div className="flex justify-between pt-2 border-t" style={{ borderColor: '#dbeafe' }}>
                  <span className="text-sm font-semibold" style={{ color: '#1e3a8a' }}>Total Charges</span>
                  <span className="text-sm font-bold num" style={{ color: '#2563eb' }}>
                    ₹{totalAdd.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Payments Table */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
          <h3 className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>Payment Records</h3>
        </div>
        <div className="table-wrap" style={{ border: 'none', borderRadius: 0 }}>
          {payments.length === 0 ? (
            <div className="text-center py-12" style={{ color: 'var(--text-muted)' }}>
              <CreditCard size={32} className="mx-auto mb-3 opacity-30" />
              <p className="text-sm">No payments for this period</p>
            </div>
          ) : (
            <table>
              <thead>
                <tr>
                  {['Tenant', 'Month', 'Rent', 'Electricity', 'Other', 'Arrears', 'Total Due', 'Paid', 'Balance', 'Status', ''].map(h => (
                    <th key={h}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {payments.map(p => (
                  <tr key={p.payment_id}>
                    <td>
                      <div className="font-medium" style={{ color: 'var(--text-primary)' }}>{p.tenant_name}</div>
                      {p.transaction_id && (
                        <div className="text-xs" style={{ color: 'var(--text-muted)' }}>#{p.transaction_id}</div>
                      )}
                    </td>
                    <td className="text-xs num" style={{ color: 'var(--text-secondary)' }}>{p.month_year}</td>
                    <td className="num">₹{p.due_amount}</td>
                    <td>
                      {p.electricity_amount > 0
                        ? <span className="num" style={{ color: '#d97706' }}>₹{p.electricity_amount}</span>
                        : <span style={{ color: 'var(--text-muted)' }}>—</span>}
                    </td>
                    <td>
                      {p.additional_amount > 0
                        ? <span className="num" style={{ color: '#2563eb' }}>₹{p.additional_amount}</span>
                        : <span style={{ color: 'var(--text-muted)' }}>—</span>}
                    </td>
                    <td>
                      {p.arrears > 0
                        ? <span className="num" style={{ color: '#ea580c' }}>₹{p.arrears}</span>
                        : <span style={{ color: 'var(--text-muted)' }}>—</span>}
                    </td>
                    <td className="font-semibold num">₹{(p.total_due + p.arrears).toLocaleString('en-IN')}</td>
                    <td className="num" style={{ color: 'var(--success)' }}>₹{p.amount_paid}</td>
                    <td>
                      {p.balance > 0
                        ? <span className="num font-semibold" style={{ color: 'var(--danger)' }}>₹{p.balance}</span>
                        : <span style={{ color: 'var(--success)' }}>—</span>}
                    </td>
                    <td>
                      <span className={`badge ${p.balance === 0 ? 'badge-green' : 'badge-red'}`}>
                        {p.balance === 0
                          ? <><CheckCircle size={9} /> Paid</>
                          : <><Clock size={9} /> Pending</>}
                      </span>
                    </td>
                    <td>
                      <div className="flex gap-1">
                        <button onClick={() => openEdit(p)}
                          className="p-1.5 rounded-lg transition-colors"
                          style={{ color: 'var(--text-muted)' }}
                          onMouseEnter={e => { e.currentTarget.style.background = '#ede9fe'; e.currentTarget.style.color = 'var(--accent)' }}
                          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--text-muted)' }}
                          title="Edit">
                          <Pencil size={13} />
                        </button>
                        <button onClick={() => setDeletePayment(p)}
                          className="p-1.5 rounded-lg transition-colors"
                          style={{ color: 'var(--text-muted)' }}
                          onMouseEnter={e => { e.currentTarget.style.background = '#fee2e2'; e.currentTarget.style.color = 'var(--danger)' }}
                          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--text-muted)' }}
                          title="Delete">
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* ── Record Payment Modal ── */}
      {showPayModal && (
        <div className="modal-overlay" onClick={() => setShowPayModal(false)}>
          <div className="modal p-7" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold">Record Payment</h2>
              <button onClick={() => setShowPayModal(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100" style={{ color: 'var(--text-muted)' }}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={submitPay} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Tenant <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <select required value={payForm.tenant_id}
                  onChange={e => setPayForm({ ...payForm, tenant_id: e.target.value })} className="input">
                  <option value="">Select tenant...</option>
                  {tenants.map(t => (
                    <option key={t.tenant_id} value={t.tenant_id}>{t.name} — {t.phone}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Month <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <input type="month" required value={payForm.month_year}
                  onChange={e => setPayForm({ ...payForm, month_year: e.target.value })} className="input" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Amount Paid (₹) <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <input type="number" required min="1" placeholder="0.00"
                  value={payForm.amount_paid}
                  onChange={e => setPayForm({ ...payForm, amount_paid: e.target.value })} className="input" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Transaction / Reference ID (optional)
                </label>
                <input type="text" placeholder="UPI ref, cheque no, etc."
                  value={payForm.transaction_id}
                  onChange={e => setPayForm({ ...payForm, transaction_id: e.target.value })} className="input" />
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={payForm.is_advance}
                  onChange={e => setPayForm({ ...payForm, is_advance: e.target.checked })}
                  className="rounded" style={{ accentColor: 'var(--accent)' }} />
                <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>Mark as advance payment</span>
              </label>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowPayModal(false)} className="btn-secondary flex-1 justify-center">
                  Cancel
                </button>
                <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
                  {loading ? 'Saving...' : 'Record Payment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── Edit Payment Modal ── TASK 3 FIX */}
      {editPayment && (
        <div className="modal-overlay" onClick={() => setEditPayment(null)}>
          <div className="modal p-7 max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold">Edit Payment</h2>
              <button onClick={() => setEditPayment(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100" style={{ color: 'var(--text-muted)' }}>
                <X size={18} />
              </button>
            </div>
            <p className="text-sm mb-4 px-3 py-2.5 rounded-xl"
              style={{ background: '#f8fafc', color: 'var(--text-secondary)' }}>
              Editing: <strong>{editPayment.tenant_name}</strong> — {editPayment.month_year}
            </p>
            <form onSubmit={saveEdit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Amount Paid (₹)</label>
                <input type="number" required min="0"
                  value={editForm.amount_paid}
                  onChange={e => setEditForm({ ...editForm, amount_paid: e.target.value })} className="input" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Transaction ID</label>
                <input type="text" value={editForm.transaction_id}
                  onChange={e => setEditForm({ ...editForm, transaction_id: e.target.value })} className="input"
                  placeholder="Optional reference" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Month</label>
                <input type="month" value={editForm.month_year}
                  onChange={e => setEditForm({ ...editForm, month_year: e.target.value })} className="input" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setEditPayment(null)} className="btn-secondary flex-1 justify-center">Cancel</button>
                <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
                  {loading ? 'Saving...' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── Delete Confirm ── TASK 3 FIX */}
      {deletePayment && (
        <div className="modal-overlay" onClick={() => setDeletePayment(null)}>
          <div className="modal p-7 max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="text-center">
              <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
                style={{ background: '#fee2e2' }}>
                <Trash2 size={22} style={{ color: 'var(--danger)' }} />
              </div>
              <h3 className="text-lg font-bold mb-2">Delete Payment?</h3>
              <p className="text-sm mb-6" style={{ color: 'var(--text-muted)' }}>
                Delete payment of <strong>₹{deletePayment.amount_paid}</strong> by{' '}
                <strong>{deletePayment.tenant_name}</strong> for {deletePayment.month_year}?
              </p>
              <div className="flex gap-3">
                <button onClick={() => setDeletePayment(null)} className="btn-secondary flex-1 justify-center">Cancel</button>
                <button onClick={confirmDelete} className="btn-danger flex-1 justify-center">Delete</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Electricity Bill Modal ── */}
      {showElecModal && (
        <div className="modal-overlay" onClick={() => setShowElecModal(false)}>
          <div className="modal p-7 max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <Zap size={18} style={{ color: '#f59e0b' }} /> Set Electricity Bill
              </h2>
              <button onClick={() => setShowElecModal(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100" style={{ color: 'var(--text-muted)' }}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={submitElec} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Room Number</label>
                <select required value={elecForm.room_number}
                  onChange={e => setElecForm({ ...elecForm, room_number: e.target.value })} className="input">
                  <option value="">Select room...</option>
                  {rooms.map(r => <option key={r.room_id} value={r.room_number}>Room {r.room_number}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Total Bill (₹)</label>
                <input type="number" required min="0" placeholder="e.g. 2400"
                  value={elecForm.total_amount}
                  onChange={e => setElecForm({ ...elecForm, total_amount: e.target.value })} className="input" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Month</label>
                <input type="month" required value={elecForm.month_year}
                  onChange={e => setElecForm({ ...elecForm, month_year: e.target.value })} className="input" />
              </div>
              <p className="text-xs px-3 py-2 rounded-lg" style={{ background: '#fffbeb', color: '#92400e' }}>
                💡 Total bill will be auto-split equally across all active tenants in this room.
              </p>
              <div className="flex gap-3">
                <button type="button" onClick={() => setShowElecModal(false)} className="btn-secondary flex-1 justify-center">Cancel</button>
                <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
                  {loading ? 'Saving...' : 'Set Bill'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── Additional Charge Modal ── */}
      {showAddModal && (
        <div className="modal-overlay" onClick={() => setShowAddModal(false)}>
          <div className="modal p-7 max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <Droplets size={18} style={{ color: '#3b82f6' }} /> Add Charge
              </h2>
              <button onClick={() => setShowAddModal(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100" style={{ color: 'var(--text-muted)' }}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={submitAdd} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Charge Name</label>
                <input type="text" required placeholder="Water, Internet, Maintenance..."
                  value={addForm.charge_name}
                  onChange={e => setAddForm({ ...addForm, charge_name: e.target.value })} className="input" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Total Amount (₹)</label>
                <input type="number" required min="0" placeholder="e.g. 3000"
                  value={addForm.total_amount}
                  onChange={e => setAddForm({ ...addForm, total_amount: e.target.value })} className="input" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Month</label>
                <input type="month" required value={addForm.month_year}
                  onChange={e => setAddForm({ ...addForm, month_year: e.target.value })} className="input" />
              </div>
              <p className="text-xs px-3 py-2 rounded-lg" style={{ background: '#eff6ff', color: '#1e3a8a' }}>
                💧 Amount will be split equally across all active tenants in the hostel.
              </p>
              <div className="flex gap-3">
                <button type="button" onClick={() => setShowAddModal(false)} className="btn-secondary flex-1 justify-center">Cancel</button>
                <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
                  {loading ? 'Saving...' : 'Add Charge'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
