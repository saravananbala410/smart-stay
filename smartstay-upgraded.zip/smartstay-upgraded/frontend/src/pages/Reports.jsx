import { useEffect, useState } from 'react'
import {
  FileText, Download, Building2, Zap, Droplets,
  Home, IndianRupee, TrendingUp, Calendar, Filter
} from 'lucide-react'
import api from '../api/axios'

export default function Reports() {
  const curMonth = new Date().toISOString().slice(0, 7)
  const [month,       setMonth]       = useState(curMonth)
  const [startDate,   setStartDate]   = useState(curMonth)
  const [endDate,     setEndDate]     = useState(curMonth)
  const [rangeMode,   setRangeMode]   = useState(false)
  const [payments,    setPayments]    = useState([])
  const [elecBills,   setElecBills]   = useState([])
  const [addCharges,  setAddCharges]  = useState([])
  const [stats,       setStats]       = useState(null)
  const [trend,       setTrend]       = useState([])
  const [loading,     setLoading]     = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const payUrl = rangeMode
        ? `/payments/?start_date=${startDate}&end_date=${endDate}`
        : `/payments/?month_year=${month}`

      const elecUrl = `/charges/electricity?month_year=${rangeMode ? startDate : month}`
      const addUrl  = `/charges/additional?month_year=${rangeMode ? startDate : month}`

      const [pRes, eRes, aRes, sRes, tRes] = await Promise.all([
        api.get(payUrl),
        api.get(elecUrl),
        api.get(addUrl),
        api.get('/dashboard/stats'),
        api.get('/reports/revenue-trend?months=6')
      ])
      setPayments(pRes.data)
      setElecBills(eRes.data)
      setAddCharges(aRes.data)
      setStats(sRes.data)
      setTrend(tRes.data)
    } catch {}
    setLoading(false)
  }

  useEffect(() => { load() }, [month, startDate, endDate, rangeMode])

  const totalCollected = payments.reduce((s, p) => s + p.amount_paid, 0)
  const totalPending   = payments.reduce((s, p) => s + p.balance, 0)
  const totalElec      = elecBills.reduce((s, b) => s + b.total_amount, 0)
  const totalAdd       = addCharges.reduce((s, c) => s + c.total_amount, 0)
  const maxTrend       = Math.max(...trend.map(t => t.collected + t.pending), 1)

  const printReport = () => window.print()

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="page-header no-print">
        <div>
          <h1 className="page-title">Reports & Bills</h1>
          <p className="page-sub">Financial summary & analytics</p>
        </div>
        <button onClick={printReport} className="btn-primary">
          <Download size={14} /> Print / PDF
        </button>
      </div>

      {/* Date Range Filter — TASK 4 FIX */}
      <div className="card p-4 no-print">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 p-1 rounded-xl" style={{ background: '#f1f5f9' }}>
            {[{ v: false, l: 'Single Month' }, { v: true, l: 'Date Range' }].map(({ v, l }) => (
              <button key={String(v)} onClick={() => setRangeMode(v)}
                className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all"
                style={rangeMode === v
                  ? { background: 'white', color: 'var(--accent)', boxShadow: '0 1px 3px rgba(0,0,0,0.08)' }
                  : { color: 'var(--text-secondary)' }
                }>{l}</button>
            ))}
          </div>

          {rangeMode ? (
            <div className="flex items-center gap-2">
              <div>
                <label className="block text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>From</label>
                <input type="month" value={startDate} onChange={e => setStartDate(e.target.value)}
                  className="input py-2 text-sm" style={{ width: '150px' }} />
              </div>
              <span className="text-sm mt-4" style={{ color: 'var(--text-muted)' }}>→</span>
              <div>
                <label className="block text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>To</label>
                <input type="month" value={endDate} onChange={e => setEndDate(e.target.value)}
                  className="input py-2 text-sm" style={{ width: '150px' }} />
              </div>
            </div>
          ) : (
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Month</label>
              <input type="month" value={month} onChange={e => setMonth(e.target.value)}
                className="input py-2 text-sm" style={{ width: '160px' }} />
            </div>
          )}
        </div>
      </div>

      {/* Revenue Trend Chart — TASK 7 Pro Feature */}
      {trend.length > 0 && (
        <div className="card p-5 no-print">
          <h3 className="font-semibold text-sm flex items-center gap-2 mb-4" style={{ color: 'var(--text-primary)' }}>
            <TrendingUp size={15} style={{ color: 'var(--accent)' }} /> Revenue Trend (Last 6 Months)
          </h3>
          <div className="flex items-end gap-2 h-28">
            {trend.map(t => (
              <div key={t.month} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full flex flex-col gap-0.5" style={{ height: '88px', justifyContent: 'flex-end' }}>
                  {/* Collected bar */}
                  <div className="w-full rounded-t-md transition-all"
                    style={{
                      height: `${(t.collected / maxTrend) * 80}px`,
                      background: 'var(--accent)',
                      minHeight: t.collected > 0 ? '4px' : '0'
                    }} title={`Collected: ₹${t.collected}`} />
                  {/* Pending bar */}
                  {t.pending > 0 && (
                    <div className="w-full rounded-b-md"
                      style={{
                        height: `${(t.pending / maxTrend) * 28}px`,
                        background: '#fee2e2',
                        minHeight: '3px'
                      }} title={`Pending: ₹${t.pending}`} />
                  )}
                </div>
                <span className="text-xs" style={{ color: 'var(--text-muted)', fontSize: '10px' }}>
                  {t.month.slice(5)}
                </span>
              </div>
            ))}
          </div>
          <div className="flex gap-4 mt-3">
            <span className="flex items-center gap-1.5 text-xs" style={{ color: 'var(--text-muted)' }}>
              <span className="w-3 h-3 rounded-sm inline-block" style={{ background: 'var(--accent)' }} /> Collected
            </span>
            <span className="flex items-center gap-1.5 text-xs" style={{ color: 'var(--text-muted)' }}>
              <span className="w-3 h-3 rounded-sm inline-block" style={{ background: '#fee2e2' }} /> Pending
            </span>
          </div>
        </div>
      )}

      {/* ── Printable Report Area ── */}
      <div id="bill-area" className="card p-6 space-y-6">
        {/* Report header */}
        <div className="text-center border-b pb-5" style={{ borderColor: 'var(--border)' }}>
          <div className="flex items-center justify-center gap-3 mb-1">
            <Building2 size={24} style={{ color: 'var(--accent)' }} />
            <h2 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
              {stats?.hostel_name || 'Hostel'}
            </h2>
          </div>
          {stats?.hostel_address && (
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>{stats.hostel_address}</p>
          )}
          <p className="font-semibold mt-2" style={{ color: 'var(--accent)' }}>
            {rangeMode
              ? `Report: ${startDate} → ${endDate}`
              : `Monthly Report — ${new Date(month + '-01').toLocaleString('en-IN', { month: 'long', year: 'numeric' })}`
            }
          </p>
          <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
            Generated on {new Date().toLocaleDateString('en-IN')}
          </p>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Total Tenants', value: payments.length, color: 'var(--accent)', bg: '#ede9fe' },
            { label: 'Collected',     value: `₹${totalCollected.toLocaleString('en-IN')}`, color: '#10b981', bg: '#dcfce7' },
            { label: 'Pending',       value: `₹${totalPending.toLocaleString('en-IN')}`,   color: '#ef4444', bg: '#fee2e2' },
            { label: 'Elec + Other',  value: `₹${(totalElec + totalAdd).toLocaleString('en-IN')}`, color: '#f59e0b', bg: '#fef9c3' },
          ].map(c => (
            <div key={c.label} className="rounded-xl p-4 text-center" style={{ background: c.bg }}>
              <p className="text-xs font-medium mb-1" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
              <p className="text-xl font-bold num" style={{ color: c.color }}>{c.value}</p>
            </div>
          ))}
        </div>

        {/* Electricity Bills */}
        {elecBills.length > 0 && (
          <div>
            <h3 className="font-semibold text-sm flex items-center gap-2 mb-3" style={{ color: 'var(--text-primary)' }}>
              <Zap size={14} style={{ color: '#f59e0b' }} /> Electricity Bills
            </h3>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    {['Room', 'Month', 'Total Bill', 'Active Tenants', 'Per Tenant'].map(h => <th key={h}>{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {elecBills.map(b => (
                    <tr key={b.bill_id}>
                      <td className="font-medium">Room {b.room_number}</td>
                      <td className="num text-xs">{b.month_year}</td>
                      <td className="num">₹{b.total_amount.toLocaleString('en-IN')}</td>
                      <td>{Math.round(b.total_amount / b.per_tenant)}</td>
                      <td><span className="font-semibold num" style={{ color: '#d97706' }}>₹{b.per_tenant}</span></td>
                    </tr>
                  ))}
                  <tr style={{ background: '#fffbeb' }}>
                    <td colSpan={2} className="font-semibold">Total Electricity</td>
                    <td className="font-bold num" style={{ color: '#d97706' }}>
                      ₹{totalElec.toLocaleString('en-IN')}
                    </td>
                    <td colSpan={2} />
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Additional Charges */}
        {addCharges.length > 0 && (
          <div>
            <h3 className="font-semibold text-sm flex items-center gap-2 mb-3" style={{ color: 'var(--text-primary)' }}>
              <Droplets size={14} style={{ color: '#3b82f6' }} /> Additional Charges
            </h3>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    {['Charge Name', 'Month', 'Total Amount', 'Per Tenant'].map(h => <th key={h}>{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {addCharges.map(c => (
                    <tr key={c.charge_id}>
                      <td className="font-medium">{c.charge_name}</td>
                      <td className="num text-xs">{c.month_year}</td>
                      <td className="num">₹{c.total_amount.toLocaleString('en-IN')}</td>
                      <td><span className="font-semibold num" style={{ color: '#2563eb' }}>₹{c.per_tenant}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tenant-wise Payments */}
        <div>
          <h3 className="font-semibold text-sm flex items-center gap-2 mb-3" style={{ color: 'var(--text-primary)' }}>
            <FileText size={14} style={{ color: 'var(--accent)' }} /> Tenant-wise Payments
          </h3>
          {loading ? (
            <p className="text-center py-8" style={{ color: 'var(--text-muted)' }}>Loading...</p>
          ) : payments.length === 0 ? (
            <p className="text-center py-8" style={{ color: 'var(--text-muted)' }}>
              No payment records for selected period
            </p>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    {['#', 'Tenant', 'Month', 'Rent', 'Electricity', 'Other', 'Arrears', 'Total Due', 'Paid', 'Balance', 'Status', 'Date'].map(h => (
                      <th key={h}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {payments.map((p, i) => (
                    <tr key={p.payment_id}>
                      <td style={{ color: 'var(--text-muted)' }}>{i + 1}</td>
                      <td className="font-medium">{p.tenant_name}</td>
                      <td className="num text-xs">{p.month_year}</td>
                      <td className="num">₹{p.due_amount}</td>
                      <td>{p.electricity_amount > 0 ? <span className="num" style={{ color: '#d97706' }}>₹{p.electricity_amount}</span> : '—'}</td>
                      <td>{p.additional_amount > 0 ? <span className="num" style={{ color: '#2563eb' }}>₹{p.additional_amount}</span> : '—'}</td>
                      <td>{p.arrears > 0 ? <span className="num" style={{ color: '#ea580c' }}>₹{p.arrears}</span> : '—'}</td>
                      <td className="font-semibold num">₹{(p.total_due + p.arrears).toLocaleString('en-IN')}</td>
                      <td className="num" style={{ color: '#10b981' }}>₹{p.amount_paid}</td>
                      <td>
                        {p.balance > 0
                          ? <span className="num font-semibold" style={{ color: '#ef4444' }}>₹{p.balance}</span>
                          : <span style={{ color: '#10b981' }}>—</span>}
                      </td>
                      <td>
                        <span className={`badge ${p.balance === 0 ? 'badge-green' : 'badge-red'}`}>
                          {p.balance === 0 ? '✓ Paid' : 'Pending'}
                        </span>
                      </td>
                      <td className="text-xs" style={{ color: 'var(--text-muted)' }}>
                        {p.payment_date ? new Date(p.payment_date).toLocaleDateString('en-IN') : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr style={{ background: '#f8fafc', fontWeight: 700 }}>
                    <td colSpan={7} style={{ padding: '10px 16px', color: 'var(--text-secondary)' }}>TOTAL</td>
                    <td style={{ padding: '10px 16px' }} className="num">
                      ₹{payments.reduce((s, p) => s + p.total_due + p.arrears, 0).toLocaleString('en-IN')}
                    </td>
                    <td style={{ padding: '10px 16px', color: '#10b981' }} className="num">
                      ₹{totalCollected.toLocaleString('en-IN')}
                    </td>
                    <td style={{ padding: '10px 16px', color: '#ef4444' }} className="num">
                      ₹{totalPending.toLocaleString('en-IN')}
                    </td>
                    <td colSpan={2} />
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t pt-4 text-center text-xs" style={{ borderColor: 'var(--border)', color: 'var(--text-muted)' }}>
          {stats?.hostel_name} · Generated by Smart-Stay · {new Date().toLocaleString('en-IN')}
        </div>
      </div>

      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white; }
          .card { box-shadow: none; }
        }
      `}</style>
    </div>
  )
}
