import { useEffect, useState } from 'react'
import {
  Users, BedDouble, IndianRupee, AlertCircle,
  Building2, Plus, Bell, MapPin, Trash2, X,
  TrendingUp, TrendingDown, Home, CheckCircle,
  BellRing, Pencil
} from 'lucide-react'
import api from '../api/axios'
import toast from 'react-hot-toast'

const BASE_URL = 'http://localhost:8000'

const StatCard = ({ icon: Icon, label, value, sub, color, trend }) => (
  <div className="stat-card">
    <div className="flex items-start justify-between mb-3">
      <div className="p-2.5 rounded-xl" style={{ background: color + '18' }}>
        <Icon size={18} style={{ color }} />
      </div>
      {trend != null && (
        <span className="text-xs flex items-center gap-0.5 font-medium"
          style={{ color: trend >= 0 ? '#10b981' : '#ef4444' }}>
          {trend >= 0 ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
          {Math.abs(trend)}%
        </span>
      )}
    </div>
    <p className="text-2xl font-bold num" style={{ color: 'var(--text-primary)' }}>{value}</p>
    <p className="text-xs font-medium mt-0.5" style={{ color: 'var(--text-secondary)' }}>{label}</p>
    {sub && <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{sub}</p>}
  </div>
)

export default function Dashboard() {
  const [stats,          setStats]          = useState(null)
  const [notices,        setNotices]        = useState([])
  const [defaulters,     setDefaulters]     = useState([])
  const [trend,          setTrend]          = useState([])
  const [noticeForm,     setNoticeForm]     = useState({ title: '', content: '' })
  const [showNoticeForm, setShowNoticeForm] = useState(false)
  const [showEditHostel, setShowEditHostel] = useState(false)
  const [hostelForm,     setHostelForm]     = useState({ address: '', image_url: '' })

  useEffect(() => {
    api.get('/dashboard/stats').then(r => {
      setStats(r.data)
      setHostelForm({ address: r.data.hostel_address || '', image_url: r.data.hostel_image || '' })
    }).catch(() => {})
    api.get('/notices/').then(r => setNotices(r.data)).catch(() => {})
    const curMonth = new Date().toISOString().slice(0, 7)
    api.get(`/reports/defaulters?month_year=${curMonth}`).then(r => setDefaulters(r.data.defaulters || [])).catch(() => {})
    api.get('/reports/revenue-trend?months=3').then(r => setTrend(r.data)).catch(() => {})
  }, [])

  const postNotice = async e => {
    e.preventDefault()
    try {
      const { data } = await api.post('/notices/', noticeForm)
      setNotices([data, ...notices])
      setNoticeForm({ title: '', content: '' })
      setShowNoticeForm(false)
      toast.success('Notice posted & SMS sent to tenants 📱')
    } catch {
      toast.error('Failed to post notice')
    }
  }

  const deleteNotice = async id => {
    try {
      await api.delete(`/notices/${id}`)
      setNotices(notices.filter(n => n.notice_id !== id))
      toast.success('Notice deleted')
    } catch {
      toast.error('Failed to delete')
    }
  }

  const saveHostelInfo = async e => {
    e.preventDefault()
    try {
      await api.patch('/dashboard/hostel-info', null, { params: hostelForm })
      toast.success('Hostel info updated!')
      setShowEditHostel(false)
      api.get('/dashboard/stats').then(r => setStats(r.data))
    } catch {
      toast.error('Failed to update')
    }
  }

  const curMonth = new Date().toISOString().slice(0, 7)
  const collectionRate = stats
    ? stats.total_collection_this_month > 0
      ? Math.round((stats.total_collection_this_month / (stats.total_collection_this_month + stats.total_pending_rent)) * 100)
      : 0
    : 0

  return (
    <div className="space-y-5">
      {/* Hostel Banner */}
      <div className="rounded-2xl p-5 text-white flex items-center gap-4 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #1e1b4b 0%, #4c1d95 100%)' }}>
        {/* Decorative */}
        <div className="absolute right-0 top-0 w-48 h-48 rounded-full opacity-10"
          style={{ background: 'white', transform: 'translate(30%, -30%)' }} />

        {stats?.hostel_image ? (
          <img
            src={stats.hostel_image.startsWith('http') ? stats.hostel_image : `${BASE_URL}/${stats.hostel_image}`}
            alt="Hostel"
            className="w-14 h-14 rounded-xl object-cover border-2 relative z-10"
            style={{ borderColor: 'rgba(255,255,255,0.2)' }}
          />
        ) : (
          <div className="w-14 h-14 rounded-xl flex items-center justify-center relative z-10"
            style={{ background: 'rgba(255,255,255,0.1)' }}>
            <Building2 size={26} className="text-white/70" />
          </div>
        )}

        <div className="flex-1 relative z-10">
          <h1 className="text-xl font-bold leading-tight">{stats?.hostel_name || 'Your Hostel'}</h1>
          {stats?.hostel_address && (
            <p className="text-sm mt-0.5 flex items-center gap-1" style={{ color: 'rgba(255,255,255,0.6)' }}>
              <MapPin size={11} /> {stats.hostel_address}
            </p>
          )}
          {/* Occupancy bar */}
          {stats && stats.total_tenants > 0 && (
            <div className="mt-2.5 flex items-center gap-2">
              <div className="flex-1 h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.2)' }}>
                <div className="h-full rounded-full" style={{
                  background: 'white',
                  width: `${Math.min(100, Math.round(stats.total_tenants / Math.max(stats.total_tenants + stats.vacant_beds, 1) * 100))}%`
                }} />
              </div>
              <span className="text-xs" style={{ color: 'rgba(255,255,255,0.7)' }}>
                {Math.round(stats.total_tenants / Math.max(stats.total_tenants + stats.vacant_beds, 1) * 100)}% occupied
              </span>
            </div>
          )}
        </div>

        <button onClick={() => setShowEditHostel(true)}
          className="text-xs px-3 py-1.5 rounded-lg relative z-10 flex items-center gap-1.5"
          style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', color: 'rgba(255,255,255,0.8)' }}>
          <Pencil size={11} /> Edit
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard
          icon={Users}       label="Active Tenants"   color="#6366f1"
          value={stats?.total_tenants ?? '—'}
        />
        <StatCard
          icon={BedDouble}   label="Vacant Beds"      color="#10b981"
          value={stats?.vacant_beds ?? '—'}
        />
        <StatCard
          icon={IndianRupee} label="Collected (Month)" color="#3b82f6"
          value={stats ? `₹${stats.total_collection_this_month.toLocaleString('en-IN')}` : '—'}
          sub={`${collectionRate}% collection rate`}
        />
        <StatCard
          icon={AlertCircle} label="Pending Rent"      color="#ef4444"
          value={stats ? `₹${stats.total_pending_rent.toLocaleString('en-IN')}` : '—'}
          sub={`${defaulters.length} defaulters`}
        />
      </div>

      <div className="grid lg:grid-cols-5 gap-5">
        {/* Left: Defaulters + Revenue trend */}
        <div className="lg:col-span-3 space-y-5">
          {/* Rent Defaulters — TASK 7 Pro Feature */}
          {defaulters.length > 0 && (
            <div className="card">
              <div className="px-5 py-4 border-b flex items-center justify-between"
                style={{ borderColor: 'var(--border)' }}>
                <h3 className="font-semibold text-sm flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                  <AlertCircle size={14} style={{ color: '#ef4444' }} />
                  Rent Defaulters — {curMonth}
                </h3>
                <span className="badge badge-red">{defaulters.length}</span>
              </div>
              <div className="divide-y" style={{ divideColor: '#f8fafc' }}>
                {defaulters.slice(0, 5).map(d => (
                  <div key={d.tenant_id} className="flex items-center justify-between px-5 py-3">
                    <div>
                      <p className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>{d.tenant_name}</p>
                      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{d.room} · {d.phone}</p>
                    </div>
                    <span className="text-sm font-bold num" style={{ color: '#ef4444' }}>
                      ₹{d.balance_due.toLocaleString('en-IN')}
                    </span>
                  </div>
                ))}
                {defaulters.length > 5 && (
                  <div className="px-5 py-3 text-xs" style={{ color: 'var(--text-muted)' }}>
                    + {defaulters.length - 5} more defaulters
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Revenue mini trend */}
          {trend.length > 0 && (
            <div className="card p-5">
              <h3 className="font-semibold text-sm flex items-center gap-2 mb-4" style={{ color: 'var(--text-primary)' }}>
                <TrendingUp size={14} style={{ color: 'var(--accent)' }} /> Revenue (Last 3 Months)
              </h3>
              <div className="space-y-2.5">
                {trend.map(t => {
                  const total = t.collected + t.pending
                  const pct   = total > 0 ? Math.round((t.collected / total) * 100) : 0
                  return (
                    <div key={t.month}>
                      <div className="flex justify-between text-xs mb-1">
                        <span style={{ color: 'var(--text-secondary)' }}>{t.month}</span>
                        <span className="num font-medium" style={{ color: 'var(--text-primary)' }}>
                          ₹{t.collected.toLocaleString('en-IN')} <span style={{ color: 'var(--text-muted)' }}>/ ₹{total.toLocaleString('en-IN')}</span>
                        </span>
                      </div>
                      <div className="h-2 rounded-full" style={{ background: '#f1f5f9' }}>
                        <div className="h-full rounded-full transition-all"
                          style={{ width: `${pct}%`, background: 'var(--accent)' }} />
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}
        </div>

        {/* Right: Notice Board */}
        <div className="lg:col-span-2">
          <div className="card h-full flex flex-col">
            <div className="px-5 py-4 border-b flex items-center justify-between"
              style={{ borderColor: 'var(--border)' }}>
              <h3 className="font-semibold text-sm flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                <BellRing size={14} style={{ color: 'var(--accent)' }} /> Notice Board
              </h3>
              <button onClick={() => setShowNoticeForm(true)} className="btn-primary" style={{ padding: '0.375rem 0.75rem', fontSize: '0.75rem' }}>
                <Plus size={12} /> Post
              </button>
            </div>

            <div className="flex-1 overflow-y-auto divide-y" style={{ divideColor: '#f8fafc', maxHeight: '400px' }}>
              {notices.length === 0 ? (
                <div className="text-center py-10" style={{ color: 'var(--text-muted)' }}>
                  <Bell size={28} className="mx-auto mb-2 opacity-30" />
                  <p className="text-sm">No notices yet</p>
                </div>
              ) : (
                notices.map(n => (
                  <div key={n.notice_id} className="px-5 py-3.5 group">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{n.title}</p>
                      <button
                        onClick={() => deleteNotice(n.notice_id)}
                        className="opacity-0 group-hover:opacity-100 p-1 rounded transition-all"
                        style={{ color: 'var(--text-muted)' }}
                        onMouseEnter={e => e.currentTarget.style.color = 'var(--danger)'}
                        onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                    <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)', lineHeight: '1.5' }}>{n.content}</p>
                    <p className="text-xs mt-1.5" style={{ color: 'var(--text-muted)' }}>
                      {new Date(n.created_at).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ── Post Notice Modal ── */}
      {showNoticeForm && (
        <div className="modal-overlay" onClick={() => setShowNoticeForm(false)}>
          <div className="modal p-7 max-w-md" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <BellRing size={17} style={{ color: 'var(--accent)' }} /> Post Notice
              </h2>
              <button onClick={() => setShowNoticeForm(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100" style={{ color: 'var(--text-muted)' }}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={postNotice} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Title <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <input type="text" required placeholder="Notice title..."
                  value={noticeForm.title}
                  onChange={e => setNoticeForm({ ...noticeForm, title: e.target.value })}
                  className="input" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  Message <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <textarea required placeholder="Notice message..." rows={4}
                  value={noticeForm.content}
                  onChange={e => setNoticeForm({ ...noticeForm, content: e.target.value })}
                  className="input resize-none" style={{ resize: 'none' }} />
              </div>
              <div className="flex items-center gap-2 p-3 rounded-xl text-xs"
                style={{ background: '#ede9fe', color: '#5b21b6' }}>
                <Bell size={13} />
                An SMS will be automatically sent to all active tenants when posted.
              </div>
              <div className="flex gap-3">
                <button type="button" onClick={() => setShowNoticeForm(false)} className="btn-secondary flex-1 justify-center">
                  Cancel
                </button>
                <button type="submit" className="btn-primary flex-1 justify-center">
                  Post & Send SMS
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── Edit Hostel Info Modal ── */}
      {showEditHostel && (
        <div className="modal-overlay" onClick={() => setShowEditHostel(false)}>
          <div className="modal p-7 max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold">Edit Hostel Info</h2>
              <button onClick={() => setShowEditHostel(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100" style={{ color: 'var(--text-muted)' }}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={saveHostelInfo} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Address</label>
                <input type="text" placeholder="123 Main Street, Chennai"
                  value={hostelForm.address}
                  onChange={e => setHostelForm({ ...hostelForm, address: e.target.value })}
                  className="input" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Image URL</label>
                <input type="url" placeholder="https://..."
                  value={hostelForm.image_url}
                  onChange={e => setHostelForm({ ...hostelForm, image_url: e.target.value })}
                  className="input" />
              </div>
              <div className="flex gap-3">
                <button type="button" onClick={() => setShowEditHostel(false)} className="btn-secondary flex-1 justify-center">
                  Cancel
                </button>
                <button type="submit" className="btn-primary flex-1 justify-center">Save</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
