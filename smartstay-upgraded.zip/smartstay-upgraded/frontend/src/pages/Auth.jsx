// Auth.jsx — ForgotPassword + ResetPassword (both fixed & styled)
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Eye, EyeOff, Mail, Lock, ArrowLeft, ArrowRight, CheckCircle } from 'lucide-react'
import api from '../api/axios'
import toast from 'react-hot-toast'

// ──────────────────────────────────────────────
// Register
// ──────────────────────────────────────────────
export function Register() {
  const [form, setForm] = useState({ name: '', owner_name: '', email: '', password: '' })
  const [loading, setLoading]   = useState(false)
  const [showPass, setShowPass] = useState(false)
  const navigate = useNavigate()

  const submit = async e => {
    e.preventDefault()
    setLoading(true)
    try {
      const { data } = await api.post('/auth/register', form)
      localStorage.setItem('token',       data.access_token)
      localStorage.setItem('hostel_id',   data.hostel_id)
      localStorage.setItem('hostel_name', data.hostel_name)
      toast.success('Hostel registered! 🎉')
      navigate('/')
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Registration failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50">
      <div className="w-full max-w-sm">
        <div className="text-center mb-7">
          <div className="text-4xl mb-2">🏠</div>
          <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Register Your Hostel</h1>
          <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>Create your management account</p>
        </div>

        <div className="card p-7">
          <form onSubmit={submit} className="space-y-4">
            {[
              { label: 'Hostel Name',  key: 'name',       placeholder: 'Sri Ram PG' },
              { label: 'Owner Name',   key: 'owner_name', placeholder: 'Ravi Kumar' },
              { label: 'Email',        key: 'email',      placeholder: 'ravi@sriram.com', type: 'email' },
            ].map(({ label, key, placeholder, type = 'text' }) => (
              <div key={key}>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                  {label}
                </label>
                <input
                  type={type}
                  required
                  placeholder={placeholder}
                  className="input"
                  value={form[key]}
                  onChange={e => setForm({ ...form, [key]: e.target.value })}
                />
              </div>
            ))}

            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Password
              </label>
              <div className="relative">
                <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--text-muted)' }} />
                <input
                  type={showPass ? 'text' : 'password'}
                  required
                  className="input pl-9 pr-10"
                  placeholder="Min 8 characters"
                  value={form.password}
                  onChange={e => setForm({ ...form, password: e.target.value })}
                />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: showPass ? 'var(--accent)' : 'var(--text-muted)' }}>
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-3 mt-2">
              {loading ? 'Creating account...' : 'Register Hostel'}
            </button>
          </form>
        </div>

        <p className="text-center text-sm mt-5" style={{ color: 'var(--text-muted)' }}>
          Already have an account?{' '}
          <Link to="/login" className="font-semibold" style={{ color: 'var(--accent)' }}>Sign in</Link>
        </p>
      </div>
    </div>
  )
}


// ──────────────────────────────────────────────
// Forgot Password  ← TASK 1 FIX
// ──────────────────────────────────────────────
export function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [sent, setSent]   = useState(false)
  const [loading, setLoading] = useState(false)

  const submit = async e => {
    e.preventDefault()
    setLoading(true)
    try {
      await api.post('/auth/forgot-password', { email })
      setSent(true)
      toast.success('Reset link sent!')
    } catch (err) {
      // Even if user not found, backend returns 200 — so any real error is shown
      toast.error(err.response?.data?.detail || 'Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50">
      <div className="w-full max-w-sm">
        <Link to="/login"
          className="inline-flex items-center gap-1.5 text-sm mb-6 transition-colors"
          style={{ color: 'var(--text-muted)' }}
          onMouseEnter={e => e.currentTarget.style.color = 'var(--accent)'}
          onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}
        >
          <ArrowLeft size={14} /> Back to login
        </Link>

        <div className="card p-8">
          {sent ? (
            <div className="text-center py-4">
              <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4"
                style={{ background: '#dcfce7' }}>
                <CheckCircle size={28} style={{ color: 'var(--success)' }} />
              </div>
              <h2 className="text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>
                Check your inbox
              </h2>
              <p className="text-sm mb-6" style={{ color: 'var(--text-muted)' }}>
                We sent a password reset link to <strong>{email}</strong>. Check your spam folder if you don't see it.
              </p>
              <Link to="/login" className="btn-primary w-full justify-center">
                Return to login
              </Link>
            </div>
          ) : (
            <>
              <div className="mb-6">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4"
                  style={{ background: '#ede9fe' }}>
                  <Mail size={18} style={{ color: 'var(--accent)' }} />
                </div>
                <h2 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>Forgot your password?</h2>
                <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>
                  Enter your email and we'll send a reset link.
                </p>
              </div>

              <form onSubmit={submit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                    Email address
                  </label>
                  <div className="relative">
                    <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2"
                      style={{ color: 'var(--text-muted)' }} />
                    <input
                      type="email"
                      required
                      className="input pl-9"
                      placeholder="your@email.com"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                    />
                  </div>
                </div>
                <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-3">
                  {loading ? 'Sending...' : (
                    <span className="flex items-center gap-2">Send reset link <ArrowRight size={14} /></span>
                  )}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}


// ──────────────────────────────────────────────
// Reset Password  ← TASK 1 FIX
// ──────────────────────────────────────────────
export function ResetPassword() {
  const [password, setPassword]       = useState('')
  const [confirmPass, setConfirmPass] = useState('')
  const [done, setDone]               = useState(false)
  const [loading, setLoading]         = useState(false)
  const [showPass, setShowPass]       = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)
  const navigate = useNavigate()

  // Read token from URL: /reset-password?token=xxxxx
  const token = new URLSearchParams(window.location.search).get('token')

  const submit = async e => {
    e.preventDefault()
    if (password !== confirmPass) {
      toast.error('Passwords do not match')
      return
    }
    if (password.length < 6) {
      toast.error('Password must be at least 6 characters')
      return
    }
    if (!token) {
      toast.error('Invalid reset link. Please request a new one.')
      return
    }
    setLoading(true)
    try {
      await api.post('/auth/reset-password', { token, new_password: password })
      setDone(true)
      toast.success('Password reset successfully!')
      setTimeout(() => navigate('/login'), 2500)
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Reset failed. The link may have expired.')
    } finally {
      setLoading(false)
    }
  }

  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50">
        <div className="card p-8 w-full max-w-sm text-center">
          <div className="text-4xl mb-3">❌</div>
          <h2 className="font-bold text-lg mb-2">Invalid Reset Link</h2>
          <p className="text-sm mb-4" style={{ color: 'var(--text-muted)' }}>
            This link is invalid or missing a token.
          </p>
          <Link to="/forgot-password" className="btn-primary w-full justify-center">
            Request new link
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50">
      <div className="w-full max-w-sm">
        <div className="card p-8">
          {done ? (
            <div className="text-center py-4">
              <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4"
                style={{ background: '#dcfce7' }}>
                <CheckCircle size={28} style={{ color: 'var(--success)' }} />
              </div>
              <h2 className="text-xl font-bold mb-2">Password updated!</h2>
              <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
                Redirecting you to login...
              </p>
            </div>
          ) : (
            <>
              <div className="mb-6">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4"
                  style={{ background: '#ede9fe' }}>
                  <Lock size={18} style={{ color: 'var(--accent)' }} />
                </div>
                <h2 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>Set new password</h2>
                <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>
                  Choose a strong password for your account.
                </p>
              </div>

              <form onSubmit={submit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                    New password
                  </label>
                  <div className="relative">
                    <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2"
                      style={{ color: 'var(--text-muted)' }} />
                    <input
                      type={showPass ? 'text' : 'password'}
                      required
                      className="input pl-9 pr-10"
                      placeholder="Min 6 characters"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                    />
                    <button type="button" onClick={() => setShowPass(!showPass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2"
                      style={{ color: showPass ? 'var(--accent)' : 'var(--text-muted)' }}>
                      {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                    Confirm new password
                  </label>
                  <div className="relative">
                    <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2"
                      style={{ color: 'var(--text-muted)' }} />
                    <input
                      type={showConfirm ? 'text' : 'password'}
                      required
                      className="input pl-9 pr-10"
                      placeholder="Repeat password"
                      value={confirmPass}
                      onChange={e => setConfirmPass(e.target.value)}
                    />
                    <button type="button" onClick={() => setShowConfirm(!showConfirm)}
                      className="absolute right-3 top-1/2 -translate-y-1/2"
                      style={{ color: showConfirm ? 'var(--accent)' : 'var(--text-muted)' }}>
                      {showConfirm ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                  {confirmPass && password !== confirmPass && (
                    <p className="text-xs mt-1" style={{ color: 'var(--danger)' }}>Passwords don't match</p>
                  )}
                </div>

                <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-3">
                  {loading ? 'Resetting...' : 'Reset password'}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
